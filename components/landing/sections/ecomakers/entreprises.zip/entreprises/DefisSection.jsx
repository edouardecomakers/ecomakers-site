import { AlertTriangle, UserX, Clock } from "lucide-react"

export default function DefisSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Les défis du recrutement GTB/GTC</h2>
        </div>
        <div className="mx-auto grid max-w-5xl gap-6 py-12 lg:grid-cols-3">
          <div className="flex flex-col items-center space-y-4 text-center p-6 bg-card rounded-lg border">
            <AlertTriangle className="h-12 w-12 text-primary" />
            <h3 className="text-xl font-bold">Le marché est en tension</h3>
            <p className="text-muted-foreground">85% des entreprises GTB peinent à recruter. 3,2 candidatures par offre vs. 12,4 tous secteurs.</p>
            <div className="space-y-2">
              <p className="font-semibold text-primary">→ Notre solution:</p>
              <p className="text-sm">Accès direct à 2000+ profils qualifiés, dont 100+ en recherche active.</p>
            </div>
          </div>
          <div className="flex flex-col items-center space-y-4 text-center p-6 bg-card rounded-lg border">
            <UserX className="h-12 w-12 text-primary" />
            <h3 className="text-xl font-bold">Les bons profils ne postulent pas</h3>
            <p className="text-muted-foreground">80% des meilleurs candidats ne répondent pas aux annonces classiques.</p>
            <div className="space-y-2">
              <p className="font-semibold text-primary">→ Notre solution:</p>
              <p className="text-sm">Approche proactive, nous contactons directement les talents.</p>
            </div>
          </div>
          <div className="flex flex-col items-center space-y-4 text-center p-6 bg-card rounded-lg border">
            <Clock className="h-12 w-12 text-primary" />
            <h3 className="text-xl font-bold">Ça prend trop de temps</h3>
            <p className="text-muted-foreground">3-4 mois en moyenne. Équipe en sous-effectif, projets refusés, heures sup.</p>
            <div className="space-y-2">
              <p className="font-semibold text-primary">→ Notre solution:</p>
              <p className="text-sm">2 profils en 7 jours. ROI évident.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}