import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"

export default function TarificationSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Une tarification simple et transparente</h2>
          <div className="space-y-2">
            <div className="text-6xl font-bold text-primary">20%</div>
            <p className="text-xl text-muted-foreground">du salaire brut annuel</p>
            <p className="text-lg font-medium">Paiement au succès uniquement</p>
          </div>
        </div>
        
        <div className="mx-auto max-w-4xl py-12 space-y-8">
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <h3 className="text-xl font-semibold">Modalités</h3>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-primary" />
                  <span>70% au démarrage du candidat</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-primary" />
                  <span>30% après validation période d'essai</span>
                </div>
              </div>
            </div>
            
            <Card className="bg-muted/50">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Exemple</h3>
                <div className="space-y-3">
                  <p className="font-medium">Automaticien à 45K€ + 3K€ avantages</p>
                  <div className="space-y-1 text-sm">
                    <p>→ Honoraires: <span className="font-semibold">9 600€</span></p>
                    <p>→ 6 720€ au démarrage + 2 880€ après validation</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="text-center">
            <div className="inline-flex items-center space-x-2 bg-primary/10 px-4 py-2 rounded-lg">
              <CheckCircle className="h-5 w-5 text-primary" />
              <span className="font-medium">Garantie incluse: Remplacement gratuit pendant période d'essai</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}