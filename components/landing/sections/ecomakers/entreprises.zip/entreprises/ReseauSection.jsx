import { Users } from "lucide-react"

export default function ReseauSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Nous ne diluons pas</h2>
          <div className="flex items-center justify-center space-x-2 py-8">
            <Users className="h-12 w-12 text-primary" />
            <span className="text-6xl font-bold text-primary">2000+</span>
          </div>
          <p className="text-xl font-semibold text-muted-foreground">profils GTB/GTC en Île-de-France</p>
        </div>
        <div className="mx-auto max-w-4xl py-12 text-center space-y-6">
          <p className="text-lg font-medium">Le plus grand réseau spécialisé de la région.</p>
          <p className="text-muted-foreground md:text-lg">
            Les cabinets généralistes ont 10 000 candidats... dont 50 en GTB qu'ils ne connaissent pas.
          </p>
          <p className="text-lg font-medium text-primary">Notre spécialisation = votre garantie de qualité.</p>
        </div>
      </div>
    </section>
  )
}