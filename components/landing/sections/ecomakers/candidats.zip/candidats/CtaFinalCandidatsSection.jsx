import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export default function CtaFinalCandidatsSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
            Prêt à faire évoluer votre carrière GTB/GTC?
          </h2>
          <p className="max-w-[600px] text-primary-foreground/80 md:text-xl">
            Rejoignez 2000+ professionnels GTB/GTC en Île-de-France
          </p>
          <div className="pt-4">
            <Button size="lg" variant="secondary" asChild>
              <a href="#formulaire" className="inline-flex items-center gap-2">
                Accédez aux meilleures opportunités
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}