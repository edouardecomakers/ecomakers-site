'use client'

import { useState } from 'react'
import { ChevronDown, ChevronUp } from 'lucide-react'

export default function FaqCandidatsSection() {
  const [openIndex, setOpenIndex] = useState(null)

  const faqs = [
    {
      question: "Confidentialité si déjà en poste?",
      answer: "Absolument. Jamais de divulgation sans accord explicite préalable. 100% confidentiel."
    },
    {
      question: "Uniquement CDI?",
      answer: "Principalement, mais aussi freelance ou CDD longue durée parfois."
    },
    {
      question: "Je suis juste \"à l'écoute\"?",
      answer: "Oui, recommandé même. Majorité du réseau = personnes en poste à l'écoute."
    },
    {
      question: "Délai première opportunité?",
      answer: "Variable selon profil et marché. 1 semaine à 2-3 mois. Contact que si offre correspond vraiment."
    },
    {
      question: "Dois-je payer?",
      answer: "Non, jamais. 100% gratuit pour candidats. Entreprises nous rémunèrent."
    },
    {
      question: "Puis-je refuser une opportunité?",
      answer: "Bien sûr. Libre d'accepter ou refuser. Aucune pression."
    }
  ]

  const toggleQuestion = (index) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Questions fréquentes</h2>
        </div>
        <div className="mx-auto max-w-3xl py-12">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-card border rounded-lg">
                <button
                  onClick={() => toggleQuestion(index)}
                  className="flex w-full items-center justify-between p-6 text-left"
                >
                  <span className="text-lg font-medium">{faq.question}</span>
                  {openIndex === index ? (
                    <ChevronUp className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-muted-foreground" />
                  )}
                </button>
                {openIndex === index && (
                  <div className="px-6 pb-6">
                    <p className="text-muted-foreground">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}