import { UserPlus, Search, Mail } from "lucide-react"

export default function ProcessCandidatsSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Le parcours candidat en 3 étapes</h2>
        </div>
        <div className="mx-auto grid max-w-5xl gap-6 py-12 lg:grid-cols-3">
          <div className="flex flex-col items-center space-y-4 text-center p-6 bg-card rounded-lg border">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <UserPlus className="h-6 w-6" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-bold">Étape 1 - Vous rejoignez le réseau</h3>
              <p className="text-muted-foreground">Formulaire en moins de 2 min. Métier, motivations, situation actuelle.</p>
            </div>
          </div>
          <div className="flex flex-col items-center space-y-4 text-center p-6 bg-card rounded-lg border">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <Search className="h-6 w-6" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-bold">Étape 2 - Nous analysons votre profil</h3>
              <p className="text-muted-foreground">Parcours LinkedIn, compétences, trajectoire. Identification opportunités correspondantes.</p>
            </div>
          </div>
          <div className="flex flex-col items-center space-y-4 text-center p-6 bg-card rounded-lg border">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <Mail className="h-6 w-6" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-bold">Étape 3 - Opportunités ciblées</h3>
              <p className="text-muted-foreground">Contact uniquement si offre correspond vraiment. Accompagnement: analyse opportunité, conseil négociation, aide décision.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}