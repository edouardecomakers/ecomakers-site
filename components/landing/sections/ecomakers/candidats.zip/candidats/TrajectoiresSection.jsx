import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

export default function TrajectoiresSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Trajectoires GTB : Contenu gratuit pour réussir votre carrière</h2>
          <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">Insights concrets pour progresser dans les métiers GTB/GTC.</p>
        </div>
        <div className="mx-auto max-w-3xl py-12">
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0 mt-0.5" />
              <p>Grilles de salaires actualisées (métier, expérience, zone)</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0 mt-0.5" />
              <p>Parcours métiers possibles (Technicien → Chef de projet, Energy Manager...)</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0 mt-0.5" />
              <p>Certifications valorisantes (lesquelles rapportent)</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0 mt-0.5" />
              <p>Tendances du secteur (réglementation, technologies, entreprises)</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0 mt-0.5" />
              <p>Conseils carrière (négociation, entretiens, évolution)</p>
            </div>
          </div>
          <div className="flex justify-center pt-8">
            <Button asChild size="lg">
              <a href="/blog">Accéder à Trajectoires GTB</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}