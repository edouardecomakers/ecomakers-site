import { Target, BookOpen, Lock } from "lucide-react"

export default function BeneficesCandidatsSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Ce que vous gagnez à rejoindre EcoMakers</h2>
        </div>
        <div className="mx-auto grid max-w-5xl gap-6 py-12 lg:grid-cols-3">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <Target className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Opportunités exclusives</h3>
            <p className="text-muted-foreground">Postes non publiés sur jobboards. Entreprises de qualité en Île-de-France.</p>
          </div>
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <BookOpen className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Contenu gratuit</h3>
            <p className="text-muted-foreground">Trajectoires GTB: grilles salaires, parcours métiers, certifications, tendances. Tout gratuit.</p>
          </div>
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <Lock className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Confidentialité garantie</h3>
            <p className="text-muted-foreground">Démarche 100% confidentielle. Jamais de divulgation sans accord explicite.</p>
          </div>
        </div>
      </div>
    </section>
  )
}